﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;

namespace ExcelAddInNetflix
{
	public partial class MyRibbon
	{
		private void MyRibbon_Load(object sender, RibbonUIEventArgs e)
		{

		}

		private void btnSearch_Click(object sender, RibbonControlEventArgs e)
		{
			Globals.ThisAddIn.SearchForFilms(this.ebSearchText.Text);
		}

		private void btnAddChart_Click(object sender, RibbonControlEventArgs e)
		{
			Globals.ThisAddIn.AddChart();
		}
	}
}
