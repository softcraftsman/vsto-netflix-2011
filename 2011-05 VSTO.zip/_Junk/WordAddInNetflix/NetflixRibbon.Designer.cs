﻿namespace WordAddInNetflix
{
	partial class NetflixRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public NetflixRibbon()
			: base(Globals.Factory.GetRibbonFactory())
		{
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tab1 = this.Factory.CreateRibbonTab();
			this.group1 = this.Factory.CreateRibbonGroup();
			this.btnTitles = this.Factory.CreateRibbonButton();
			this.btnPeople = this.Factory.CreateRibbonButton();
			this.group2 = this.Factory.CreateRibbonGroup();
			this.dropDown1 = this.Factory.CreateRibbonDropDown();
			this.gallery1 = this.Factory.CreateRibbonGallery();
			this.label1 = this.Factory.CreateRibbonLabel();
			this.tab2 = this.Factory.CreateRibbonTab();
			this.group3 = this.Factory.CreateRibbonGroup();
			this.comboBox1 = this.Factory.CreateRibbonComboBox();
			this.checkBox1 = this.Factory.CreateRibbonCheckBox();
			this.buttonGroup1 = this.Factory.CreateRibbonButtonGroup();
			this.button1 = this.Factory.CreateRibbonButton();
			this.button2 = this.Factory.CreateRibbonButton();
			this.button3 = this.Factory.CreateRibbonButton();
			this.tab1.SuspendLayout();
			this.group1.SuspendLayout();
			this.group2.SuspendLayout();
			this.tab2.SuspendLayout();
			this.group3.SuspendLayout();
			this.buttonGroup1.SuspendLayout();
			// 
			// tab1
			// 
			this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
			this.tab1.Groups.Add(this.group1);
			this.tab1.Groups.Add(this.group2);
			this.tab1.Label = "TabAddIns";
			this.tab1.Name = "tab1";
			// 
			// group1
			// 
			this.group1.Items.Add(this.btnTitles);
			this.group1.Items.Add(this.btnPeople);
			this.group1.Label = "group1";
			this.group1.Name = "group1";
			// 
			// btnTitles
			// 
			this.btnTitles.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
			this.btnTitles.Image = global::WordAddInNetflix.Properties.Resources.Chrysanthemum;
			this.btnTitles.Label = "Titles";
			this.btnTitles.Name = "btnTitles";
			this.btnTitles.ShowImage = true;
			this.btnTitles.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnTitles_Click);
			// 
			// btnPeople
			// 
			this.btnPeople.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
			this.btnPeople.Image = global::WordAddInNetflix.Properties.Resources.Lighthouse;
			this.btnPeople.Label = "People";
			this.btnPeople.Name = "btnPeople";
			this.btnPeople.ShowImage = true;
			this.btnPeople.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnPeople_Click);
			// 
			// group2
			// 
			this.group2.Items.Add(this.dropDown1);
			this.group2.Items.Add(this.gallery1);
			this.group2.Items.Add(this.label1);
			this.group2.Label = "group2";
			this.group2.Name = "group2";
			// 
			// dropDown1
			// 
			this.dropDown1.Label = "dropDown1";
			this.dropDown1.Name = "dropDown1";
			// 
			// gallery1
			// 
			this.gallery1.Label = "gallery1";
			this.gallery1.Name = "gallery1";
			// 
			// label1
			// 
			this.label1.Label = "label1";
			this.label1.Name = "label1";
			// 
			// tab2
			// 
			this.tab2.Groups.Add(this.group3);
			this.tab2.Label = "tab2";
			this.tab2.Name = "tab2";
			// 
			// group3
			// 
			this.group3.Items.Add(this.comboBox1);
			this.group3.Items.Add(this.checkBox1);
			this.group3.Items.Add(this.buttonGroup1);
			this.group3.Label = "group3";
			this.group3.Name = "group3";
			// 
			// comboBox1
			// 
			this.comboBox1.Label = "comboBox1";
			this.comboBox1.Name = "comboBox1";
			// 
			// checkBox1
			// 
			this.checkBox1.Label = "checkBox1";
			this.checkBox1.Name = "checkBox1";
			// 
			// buttonGroup1
			// 
			this.buttonGroup1.Items.Add(this.button1);
			this.buttonGroup1.Items.Add(this.button2);
			this.buttonGroup1.Items.Add(this.button3);
			this.buttonGroup1.Name = "buttonGroup1";
			// 
			// button1
			// 
			this.button1.Label = "button1";
			this.button1.Name = "button1";
			// 
			// button2
			// 
			this.button2.Label = "button2";
			this.button2.Name = "button2";
			// 
			// button3
			// 
			this.button3.Label = "button3";
			this.button3.Name = "button3";
			// 
			// NetflixRibbon
			// 
			this.Name = "NetflixRibbon";
			this.RibbonType = "Microsoft.Word.Document";
			this.Tabs.Add(this.tab1);
			this.Tabs.Add(this.tab2);
			this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.NetflixRibbon_Load);
			this.tab1.ResumeLayout(false);
			this.tab1.PerformLayout();
			this.group1.ResumeLayout(false);
			this.group1.PerformLayout();
			this.group2.ResumeLayout(false);
			this.group2.PerformLayout();
			this.tab2.ResumeLayout(false);
			this.tab2.PerformLayout();
			this.group3.ResumeLayout(false);
			this.group3.PerformLayout();
			this.buttonGroup1.ResumeLayout(false);
			this.buttonGroup1.PerformLayout();

		}

		#endregion

		internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
		internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
		internal Microsoft.Office.Tools.Ribbon.RibbonButton btnTitles;
		internal Microsoft.Office.Tools.Ribbon.RibbonButton btnPeople;
		internal Microsoft.Office.Tools.Ribbon.RibbonGroup group2;
		internal Microsoft.Office.Tools.Ribbon.RibbonDropDown dropDown1;
		internal Microsoft.Office.Tools.Ribbon.RibbonGallery gallery1;
		internal Microsoft.Office.Tools.Ribbon.RibbonLabel label1;
		internal Microsoft.Office.Tools.Ribbon.RibbonTab tab2;
		internal Microsoft.Office.Tools.Ribbon.RibbonGroup group3;
		internal Microsoft.Office.Tools.Ribbon.RibbonComboBox comboBox1;
		internal Microsoft.Office.Tools.Ribbon.RibbonCheckBox checkBox1;
		internal Microsoft.Office.Tools.Ribbon.RibbonButtonGroup buttonGroup1;
		internal Microsoft.Office.Tools.Ribbon.RibbonButton button1;
		internal Microsoft.Office.Tools.Ribbon.RibbonButton button2;
		internal Microsoft.Office.Tools.Ribbon.RibbonButton button3;
	}

	partial class ThisRibbonCollection
	{
		internal NetflixRibbon NetflixRibbon
		{
			get { return this.GetRibbon<NetflixRibbon>(); }
		}
	}
}
